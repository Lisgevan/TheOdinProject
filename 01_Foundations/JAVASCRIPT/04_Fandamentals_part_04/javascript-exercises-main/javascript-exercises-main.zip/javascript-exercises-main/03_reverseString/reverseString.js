const reverseString = function(str) {

};

// Do not edit below this line
module.exports = reverseString;
