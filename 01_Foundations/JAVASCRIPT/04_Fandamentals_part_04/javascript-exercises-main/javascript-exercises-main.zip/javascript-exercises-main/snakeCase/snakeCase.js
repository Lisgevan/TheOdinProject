const snakeCase = function() {

};

// Do not edit below this line
module.exports = snakeCase;
