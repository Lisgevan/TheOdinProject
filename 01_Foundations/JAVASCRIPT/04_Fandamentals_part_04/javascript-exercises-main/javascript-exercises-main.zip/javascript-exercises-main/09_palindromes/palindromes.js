const palindromes = function () {

};

// Do not edit below this line
module.exports = palindromes;
