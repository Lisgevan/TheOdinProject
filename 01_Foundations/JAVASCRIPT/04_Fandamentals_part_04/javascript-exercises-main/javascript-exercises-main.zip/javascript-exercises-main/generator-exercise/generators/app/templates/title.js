let <%= title %> = function() {

};

module.exports = <%= title %>;
